var STATIC_CACHE_VERSION = 'static-v13';
var DYNAMIC_CAHCE_VERSION = 'dynmaic-v04';

var CACHE_STATIC_FILES = [
  '/index.html',
  '/offline.html',
  '/src/js/app.js',
  '/src/js/material.min.js',
  '/src/css/app.css',
  '/src/css/feed.css',
  '/src/css/help.css',
  '/src/images/main-image-lg.jpg',
  '/src/images/main-image-sm.jpg',
  '/src/images/main-image.jpg',
  'https://fonts.googleapis.com/css?family=Roboto:400,700',
  'https://fonts.googleapis.com/icon?family=Material+Icons',
  'https://cdnjs.cloudflare.com/ajax/libs/material-design-lite/1.3.0/material.indigo-pink.min.css',
];


self.addEventListener('install', function(event) {
  event.waitUntil(
    caches.open(STATIC_CACHE_VERSION)
      .then(function (cache) {
        console.log('[Service Worker] pre-caching completed..');
        cache.addAll(CACHE_STATIC_FILES);
      })
  );
  console.log('[Service Worker] Installing Service Worker ...', event);
});

self.addEventListener('activate', function(event) {
  console.log('[Service Worker] Activating Service Worker ....', event);
  event.waitUntil(
    caches.keys()
      .then(function (keyList) {
        return Promise.all(keyList.map(function (key) {
          if (key !== STATIC_CACHE_VERSION && key !== DYNAMIC_CAHCE_VERSION) {
            console.log('[Service Worker] old cache deleted..');
            return caches.delete(key);
          }
        }));
      })
  );
  return self.clients.claim();
});

function isAppShell(url, files) {
  for (var i = 0; i < files.length; i++) {
    //console.log('check matched..', url, files[i]);
    if (url === files[i]) {
      console.log('matched..', url, files[i]);
      return true;
    }
  }
  return false;
}

var url = 'https://pwa-gram-a1e0b.firebaseio.com/posts.json';
  
self.addEventListener('fetch', function(event) {
  //console.log('[Service Worker] Fetching something ....', event);
  console.log(event.request.url);
  if (event.request.url.indexOf(url) > -1) {
    // 네트웍 요청일 때
    // cache then network & dynamic caching
    console.log('network request..', event.request.url);
    event.respondWith(
      caches.open(DYNAMIC_CAHCE_VERSION)
        .then(function (cache) {
          return fetch(event.request)
            .then(function (res) {
              cache.put(event.request.url, res.clone());
              return res;
            })
        })
    );
  } else if (isAppShell(event.request.url, CACHE_STATIC_FILES)) { 
    // App Shell 요청 할때는 "cache only"
    event.respondWith(
      caches.match(event.request)
    );
  } else {
    // 오프라인 일때
    event.respondWith(
      caches.match(event.request)
        .then(function (response) {
          if (response) {
            console.log('off line & cache..');
            return response;
          } else {
            return fetch(event.request)
              .then(function (res) {
                // 다이나믹 캐시에 저장
                caches.open(DYNAMIC_CAHCE_VERSION)
                  .then(function (cache) {
                    cache.put(event.request.url, res.clone());
                    return res;
                  })
              });
          }
        })
        .catch(function (err) {
          return caches.open(STATIC_CACHE_VERSION)
            .then(function (cache) {
              return cache.match('/offline.html');
            });
        })
    );
  }

  


  // network only
  // event.respondWith(fetch(event.request));


  // cache only
  // event.respondWith(
  //   caches.match(event.request)
  // );
  
  
});
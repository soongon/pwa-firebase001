var sharedMomentsArea = document.querySelector('#shared-moments');

function createCard(contentArray) {
  var cardWrapper = document.createElement('div');
  cardWrapper.className = 'shared-moment-card mdl-card mdl-shadow--2dp';
  var cardTitle = document.createElement('div');
  cardTitle.className = 'mdl-card__title';
  cardTitle.style.backgroundImage = 'url(' + contentArray[0] + ')';
  cardTitle.style.backgroundSize = 'cover';
  cardTitle.style.height = '180px';
  cardWrapper.appendChild(cardTitle);
  var cardTitleTextElement = document.createElement('h2');
  cardTitleTextElement.className = 'mdl-card__title-text';
  cardTitleTextElement.textContent = contentArray[2];
  cardTitle.appendChild(cardTitleTextElement);
  var cardSupportingText = document.createElement('div');
  cardSupportingText.className = 'mdl-card__supporting-text';
  cardSupportingText.textContent = contentArray[1];
  cardSupportingText.style.textAlign = 'center';
  cardWrapper.appendChild(cardSupportingText);
  componentHandler.upgradeElement(cardWrapper);
  sharedMomentsArea.appendChild(cardWrapper);
}

function clearCards() {
  while (sharedMomentsArea.hasChildNodes()) {
    sharedMomentsArea.removeChild(sharedMomentsArea.lastChild);
  }
}

var url = 'https://pwa-gram-a1e0b.firebaseio.com/posts.json';
var networkDataReceived = false;

fetch(url)
  .then(function(res) {
    return res.json();
  })
  .then(function(data) {
    networkDataReceived = true;
    console.log('From network', data);
    var content = [];
    content.push(data['first-post']['image']);
    content.push(data['first-post']['location']);
    content.push(data['first-post']['title']);
    clearCards();
    createCard(content);
  })
  .catch(function (err) {
    console.log('Network fail..', err);
  });

if ('caches' in window) {
  caches.match(url)
    .then(function (res) {
      if (res) {
        return res.json();
      } 
    })
    .then(function (data) {
      console.log('From cache..', data);
      if (!networkDataReceived) {
        var content = [];
        content.push(data['first-post']['image']);
        content.push(data['first-post']['location']);
        content.push(data['first-post']['title']);
        clearCards();
        createCard(content);
      }
    })
}


